package com.example.barrera_miranda

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.Toast
import androidx.activity.viewModels
//import com.bignerdranch.android.barrera_miranda.databinding.ActivityMainBinding
//import com.bignerdranch.android.Barrera_Miranda.databinding.ActivityMainBinding
import com.example.barrera_miranda.databinding.ActivityMainBinding

private const val TAG = "MainActivity"

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val quizViewModel: QuizViewModel by viewModels()

    //private lateinit var trueButton: Button
    //private lateinit var falseButton: Button



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.d(TAG, "OnCreate(Bundle?) called")
        //setContentView(R.layout.activity_main)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        Log.d(TAG, "Got a QuizModelView: $quizViewModel: $quizViewModel")


        //trueButton = findViewById(R.id.true_button)
        //falseButton = findViewById(R.id.false_button)

      binding.trueButton.setOnClickListener{view: View ->
          checkAnswer(true)
      }

      binding.falseButton.setOnClickListener{view: View->
          checkAnswer(false)
      }

        binding.nextButton.setOnClickListener{
            //currentIndex = (currentIndex +1)%questionBank.size
            //val questionTextResId = questionBank[currentIndex].textResId
            //binding.questionTextView.setText(questionTextResId)
            quizViewModel.moveToNext()
            updateQuestion()
        }

        //val questionTextResId = questionBank[currentIndex].textResId
        //binding.questionTextView.setText(questionTextResId)
        updateQuestion()

    }
    override fun OnStart(){
        super.onStart()
        Log.d(TAG, "onStart() called")
    }

    override fun OnResume(){
        super.onResume()
        Log.d(TAG, "onResume() called")
    }

    override fun OnPause(){
        super.onPause()
        Log.d(TAG, "onPause() called")
    }
    override fun OnStop(){
        super.onStop()
        Log.d(TAG, "onStop() called")
    }
    override fun OnDestroy(){
        super.onDestroy()
        Log.d(TAG, "onDestroy() called")
    }
    private fun updateQuestion(){
        //val questionTextResId = questionBank[currentIndex].textResId
        val questionTextResId = quizViewModel.currentQuestionText
        binding.questionTextView.setText(questionTextResId)

    }

    private fun checkAnswer (userAnswer: Boolean){
        //val correctAnswer = questionBank[currentIndex].answer
        val correctAnswer = quizViewModel.currentQuestionAnswer

        val messageResId = if(userAnswer == correctAnswer){
            R.string.correct_toast
        }else{
            R.string.incorrect_toast
        }

        Toast.makeText(this, messageResId, Toast.LENGTH_SHORT).show()
    }


}