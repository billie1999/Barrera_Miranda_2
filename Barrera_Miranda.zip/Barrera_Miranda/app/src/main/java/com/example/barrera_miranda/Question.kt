package com.example.barrera_miranda

import androidx.annotation.StringRes

data class Question (@StringRes val textResId: Int, val answer: Boolean)